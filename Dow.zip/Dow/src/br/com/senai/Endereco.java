package br.com.senai;

public class Endereco {
}
